-------------------------------- SF-388A Defender HMAC-------------------------------------------
Fighter model = Paul "DarkestVorlon" Rogers
Landing gear = Pheagey Grean
Textures = Pheagey Grean, modified by Paul "DarkestVorlon" Rogers
.def = Paul "DarkestVorlon" Rogers



   


     Thank you for downloading my first mod ship for Starshatter, and coincidentaly my first 3D model. This will be one of many in a series, culminating with a custom campaign for StarShatter. A big thank you goes to pheagey for the tutorials, and hosting at SSD, and to the SS community for the support they gave me with all the idiotic questions I posted up about this and that, and of course to Milo for making Starshatter!


To install simply unzip to yuor SS directory, it will place the SF-388A folder in yoru ships/mods directory automaticaly, or make the directorys if they arent present. To run the fighter in a mission, yuo must add her to a custom mission or make a skirmish mission with the fighter in. The loadouts do not follow the normal SS conventions, STA 1 and STA 2 are the OUTER wing pylons, 3 and 4 are the inner pylons and 5 and 6 are the internal bay's. There are no custom weapons yet, those will follow soon as well as a updated /def for the Defender. 



Disclaimer time.

This mod is NOT distibuted or supported by John Dicamillo, and both he and I arent responsible for yuor PC erupting into flames, destroying the internet or causing a giant meteor to crash into the world ;)


This file may be distributed freely on any website provided the zip file is unchanged and this Readme is included. To use this fighter in any custom mods contact my at vampyre_kain@hotmail.com or via the SS forums.



Check out Starshatter at www.starshatter.com 

Visit Starshatter Dev at http://ssd.servehttp.com/ssd/index.php


Again, Thanks to Milo for making SS and a BIG thanks to pheagey for making the main textures, letting me use his landing gear from the Master bomber and for hosting SSD where this file was orginaly hosted!