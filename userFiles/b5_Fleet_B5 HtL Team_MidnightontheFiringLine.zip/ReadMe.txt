Babylon 5 : Midnight on the Firing Line
---------------------------------------

1.	Release Information
2.	Know Issues
3.	Bug Reporting
4.	Upcomming
5.	Credits




1.	Release Information

	This is our fire public release, it is a beta version of the release intended
for the demo version of Starshatter. More then anything this release was used to 
experiment with Starshatter and learn the ins and outs of modding for it.
	


2.	Know Issues.

	1. Bolts may sometimes appear "far" in the cockpit view.
	2. Thrusters are visible sometimes in cockpit view.
	3. Missions are simple, there just is not enough time to devote to making complex missions
for an old version when the new version of Starshatter permits so much more.
	4. The Dat file may require you to re-start Starshatter after enabling it, or trying to create
a custom missoin, sometimes it does not pick it up.
	5. At this point most of the sounds are still stand-ins.



3.	Bug Reporting.
	
	Please create a txt file with the bugs you find and email them to DamoclesX@shaw.ca AND
damoclesx@holdtheline.ca.
	


4.	Upcomming

	We are currently beginning work on the first "total conversion" mod for Starshatter, the first 
phase will focus on the EArth Alliance civil war. It will include all the ships, planets, and bases
of that battle. This includes an entire custom galaxy created right down to every last planet. And yes,
you will be able to bomb the mars colony!



5.	Credits.

Team Lead 
	- DamoclesX


3D Dev.
	- All Models and Textures were created 100% from scratch by DamoclesX unless otherwise stated.
	- Executioner_de contributed the Raider Battlewagon and the Raider Fighter models.

2D Dev.
	- Map/Nav Icons - Pheagey.

Bugtesting
	- Pheagey
	- DamoclesX

Sounds
	- Executioner_de
	- DamoclesX

Missions
	- DamoclesX



Come see us.
http://www.members.shaw.ca/holdtheline/
http://ssd.servehttp.com/ssdv2

	