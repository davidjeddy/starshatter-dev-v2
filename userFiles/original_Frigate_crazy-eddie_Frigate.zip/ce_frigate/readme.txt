Creator:	Crazy-Eddie
Website:	Http://www.angelfire/lycos.com/scifi2/starshatter
eMail:		-

Name:		frigate
Class:		frigate
Details:	-

Release Date:	1/2002
Release Version:Version1 (alpha)
Release Notes:	unfinished

Copyright Stuff: