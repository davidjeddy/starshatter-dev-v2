A Shattered Universe  v 0.2

By Andrew Robb (AKA Necromancer)

This will be the first of several test releases of my Total Conversion of Star Shatter.
What I'm attempting to do with this release is get some user feed-back on how the mod 'feels' as far as game-play and balance (I'm balancing the ships on the fly for the most part). There are 2 fleets included in this release (The United Star Systems and their opponent, the Orion Trade Confederation).  I've created 2 test missions for you to get a feeling of large-scale combat in this universe, and you SHOULD have the ability to use all of the ships I've created in Custom missions.

Having said all that, there are currently no LODs in place for any of the capitol ships. 
Each ship is ranging around 2,000 to 5,000 polys, so older systems may take a beating trying to use this release.

Thanks and post any comments to either milo's site or Pheagey's site, I'll be more than happy to answer any questions or comments there.

Necromancer