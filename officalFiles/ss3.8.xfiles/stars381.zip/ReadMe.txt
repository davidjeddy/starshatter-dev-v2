STARSHATTER(TM) BETA 3.8.1
README FILE
15 June, 2003
Copyright � 2003 John DiCamillo

http://www.starshatter.com
milo@starshatter.com

******************************************************************
***
*** NOT FOR REDISTRIBUTION
***
*** This is a CLOSED BETA RELEASE of Starshatter.  Beta
*** participation is by INVITATION ONLY.  DO NOT UPLOAD
*** THE BETA FILES TO ANY PUBLIC SERVER.
***
*** Aside from agreeing not to share the game itself with
*** other people, you are not bound by a non-disclosure
*** agreement (NDA).  You may freely discuss the game with
*** anyone, and you may post screenshots you take of game
*** content on any website you choose.  Please observe
*** standards of Internet etiquette, and do not post large
*** images in unrelated news groups or website forums.
***
******************************************************************

INTRODUCTION

Thank you for downloading the Starshatter Beta 3.8.1.  This README
will give you a brief introduction to the game and how to play it.
Additional instructions are included in the game itself.  The
final version of the game will also include a comprehensive player
manual.

What Is Starshatter?

Starshatter is a new space combat simulation game that is currently
in the final stages of development.  The game offers a new type of
combat experience in an original science fiction universe.  Unlike
most other games, which limit the player to flying fighters and other
small craft, Starshatter gives you the opportunity to directly command
a wide variety of ships, from agile atmospheric and space-based
fighters to giant cruisers and fleet carriers.  Starshatter aims
to simulate the complete space combat experience -- from planet
surface to interstellar space -- with several dynamic campaigns set
in a persistent simulated universe.

Starshatter is being developed for IBM PC compatibles running Microsoft
Windows 95/98/ME/NT4/2000/XP.

Game Features

� Intelligent Combat Scenarios
� Realistic Physics
� 	Newtonian Space Combat (with computer assist)
� 	Hardcore Atmospheric Flight Modeling
� Realistic Sensors and Avionics
� Realistic Space Environments
� Stunning 3D Accelerated Graphics
� Stereo Sound

What Is This Demo All About?

This beta release is essentially feature complete.  The main
areas that need completion are multiplayer support and more
content.  At this point in development, we are mainly trying
to find and fix bugs.
	
After you've had a chance to play the game a bit, please tell
me what you think of it!  Any and all comments are welcome --
good and bad alike.  The main thing I want to know is: did you
enjoy the game?  And are you interested in playing the full
game when it is complete?  Send your comments to
milo@starshatter.com.


HARDWARE REQUIREMENTS

Recommended System:
Pentium II 400 MHz (or equivalent)
64 MB system RAM
128 MB available hard disk space
Direct3D compatible 3D accelerator with AGP 2x and 32 MB RAM
DirectX compatible Sound Card
3 or 4 Axis Joystick with 4 buttons and hat switch
Mouse

OPERATING SYSTEM AND DRIVERS

Starshatter is being developed for IBM PC compatibles running Microsoft
Windows 95/98/ME/NT4/2000/XP.  Starshatter uses DirectX to
access audio and video hardware.  You must have at least DirectX 7
installed in order to use 3D hardware accelerated graphics.

INSTALLATION

The Starshatter Beta is being distributed as a compressed archive (ZIP
file).  To install the game, create a directory of your choice (e.g.
C:\Games\Starshatter) and unzip the contents of the archive into it.
To play the game, double click the STARS.EXE icon in the new directory.

To uninstall the game, simply delete the directory and all its contents.
The Starshatter Beta will not modify the system registry, or any other
directory on your computer.

CONFIGURATION

By default, Starshatter comes configured for the "Standard" game
model, which uses realistic Newtonian physics and is a moderately
complex simulation of the vehicles involved.  This game model is
ideal if you enjoy flying military flight simulations such as
F22:TAW or Falcon 4.0.

Starshatter can also be configured for a more traditional "arcade"
style of space combat, using a simpler physics engine and more
streamlined HUD readouts.  This game model is ideal if you prefer
flying space combat sims such as Wing Commander or Freespace.
To configure Starshatter for the simplified game model, go to the
GAMEPLAY setup screen and choose "Simplified" or "Arcade" for
every setting that offers those options.

BASIC CONTROLS

This is the minimum set of controls you need to know to control your
ship and play the game:

Pitch Up                   Arrow Down     Joystick Back
Pitch Down                 Arrow Up       Joystick Forward
Yaw (Turn) Left            Arrow Left     Joystick Left
Yaw (Turn) Right           Arrow Right    Joystick Right

Increase Throttle          A
Decrease Throttle          Z

Target Ship in Reticle     T
Fire Primary Weapons       Ctrl           Joystick Button 1
Fire Secondary Weapons     Space          Joystick Button 2

Exit to Menu               Esc

There are many more controls available, and all of the keyboard
commands can be remapped to suit your preferences.  To manage
the keyboard, mouse, and joystick control mappings, access the
in-game CONTROL dialog from the main menu.

CONTACT INFORMATION

http://www.starshatter.com
milo@starshatter.com


The Starshatter Universe and all related indicia
Copyright � 1997-2003 John DiCamillo
All rights reserved.
