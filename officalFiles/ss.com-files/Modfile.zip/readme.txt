STARSHATTER(TM) MOD ARCHIVER
README FILE
12 December, 2002
Copyright � 2002 John DiCamillo

http://www.starshatter.com
milo@starshatter.com


INTRODUCTION

Thank you for downloading the Starshatter Mod Archiver.  You
can use this tool to create "packaged" (i.e. compressed) archive
files of your custom mods that can easily be distributed to and
installed by your users.  This file provides basic instructions
on how to use the archive tool.

The Mod Archive tool (modfile.exe) is a command line utility that
creates .dat files that contain all of the data needed to run your
mod in the Starshatter game engine.  You run the archiver by typing

  modfile [modname].dat

The archiver will then search through the current directory and
sub-directories for files that can be included in the mod.  The
archiver will automatically include all files with extensions
*.def, *.pcx, *.mag, *.wav, and *.txt.  It will always ignore files
with extensions *.exe, *.bat, *.cmd, *.dat, *.zip, and *.psd.

Each time you run the archiver, it will create a new copy of the
mod archive .dat file, overwriting the old one if it is still in
the same directory.  It is a good idea to build your mod in a
subdirectory of the Starshatter game directory named after your
mod (e.g. C:\games\starshatter\DragonEye).

For more information, please join the online message board for
the game at the official website.


INSTRUCTIONS

1. Unzip this file into a *new* sub-directory of the folder where you
have Starshatter installed.  Call the new directory "Deploy" or "Dragon"
or whatever the name of your particular mod may be.

2. You can delete the files ships.txt and weapons.txt - they are just there
to hold up the directory structure.

3. Copy all of your mod ships and weapons into the directories provided for
them.  If you have missions that you want me to test, copy your
Mods/Missions directory into the deployment as well.

4. If you want to create a new scripted campaign, place your missions in a
new subdirectory of Mods, named after your particular mod (e.g. Mods/Dragon).
Place all of the scripted missions in that directory, and edit the missions.def
file to describe each of them in the order you wish them to be played.  Add
a line to the mod_info.def file naming your new campaign (see the example
provided in the included mod_info.def file)

5. Edit the mod_info.def file to provide descriptions of your mod, including
your copyright notice, author name, and a logo bitmap (128 x 128).

6. Open a command prompt and cd to the newly created deployment directory.

7. Type "modfile dragon.dat" and hit return.

8. Copy the packaged mod file into the Starshatter game directory.

9. Run Starshatter, go to MISSIONS - MOD CONFIG and select and ENABLE the
new mod.  Click ACCEPT.


CONTACT INFORMATION

http://www.starshatter.com
milo@starshatter.com


The Starshatter Universe and all related indicia
Copyright � 1997-2002 John DiCamillo
All rights reserved.

