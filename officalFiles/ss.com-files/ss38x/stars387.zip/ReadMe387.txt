STARSHATTER(TM) BETA 3.8.7
README FILE
10 December, 2003
Copyright � 2003 John DiCamillo

http://www.starshatter.com
milo@starshatter.com

******************************************************************
***
*** NOT FOR REDISTRIBUTION
***
*** This is a CLOSED BETA RELEASE of Starshatter.  Beta
*** participation is by INVITATION ONLY.  DO NOT UPLOAD
*** THE BETA FILES TO ANY PUBLIC SERVER.
***
*** Aside from agreeing not to share the game itself with
*** other people, you are not bound by a non-disclosure
*** agreement (NDA).  You may freely discuss the game with
*** anyone, and you may post screenshots you take of game
*** content on any website you choose.  Please observe
*** standards of Internet etiquette, and do not post large
*** images in unrelated news groups or website forums.
***
******************************************************************

Thank you for downloading the Starshatter Beta 3.8.7.

----------------------------------------------------------------

NEW FEATURES AND FIXES SINCE 3.8.6:
* Campaign Three is complete
* Multiplayer client configuration check (anti-cheating measure)
* Thrusters will fire during ship rotation (mods only)
* HUD shows contact name for all contacts
* New planet surface - Haiche desert mining outpost
* New background nebula for Borova
* New ship designs - Thunderbolt, Devastator, Vendetta
* All fighters now have visible hardpoints

* FIXED: shields can now have holes
* FIXED: eclipse bug (very rare)
* FIXED: multiple inbound bug
* FIXED: HUD mode nav bug (autonav disabled)
* FIXED: HUD mode ILS bug
* FIXED: campaign system assignments bug
* FIXED: atmospheric density calcs
* FIXED: maximum agility penalty for heavy weapons
* OTHER: Mod version number is now a string instead of a simple number

NEW FEATURES AND FIXES SINCE 3.8.5a:
* MAIL messages from friends and colleagues during missions
* Campaign Three is a bit further along, but still not done

* FIXED: starship groups will move apart from one another
   between campaign missions (to prevent the mother-of-all-
   furballs)
* FIXED: fighters now engage starships using anti-ship missiles
* FIXED: destroyer patrol missions now have more enemies
* FIXED: navpoints now generated for warships when they are escorting
   you

NEW FEATURES AND FIXES SINCE 3.8.5:
* Target selection icon indicates when in primary weapon range (looks
   like a broken circle when out of range, circle with triangles at the 
   corners when in range)
* HUD Warning panel automatically closed before starting new mission

* FIXED: mission editor will not allow "blank" loadout
* FIXED: map window drawing order bug
* FIXED: no afterburner effect if engine is damaged or out of power
* FIXED: dedicated server crash bug
* FIXED: farcasters now working in campaign as well as single missions
* FIXED: reduced fuel consumption when not using engines
* FIXED: stations and farcasters will no longer move around between
   missions as if they were starships on patrol
 

NEW FEATURES AND FIXES SINCE 3.8.3:
* Installer instead of ZIP file
* First-run configuration dialog
* Better end of campaign message
* Partial 3rd campaign Operation Shining Fortress
* New star systems
* PDBs and shields automatically enabled
* MFD settings stored in user profile automatically
* Combat music mode is working
* Allowed to dock at neutral stations during campaign
* Support for 640x480 and 1024x768
* Patrol movement of starship groups between missions
* Move patrol command sets AI to self-defense
* trigger event supports list of events (or-condition)
* trigger event ALL supports list of events (and-condition)

* FIXED: assault navpoint marked complete too soon
* FIXED: loss of focus when editing an event
* FIXED: select last even when adding
* FIXED: multiplayer self destruct
* FIXED: multiplayer beam cutoff
* FIXED: multiplayer weapon modes for in progress join
* FIXED: multiplayer damage, shield levels
* FIXED: nike missile damage too high
* FIXED: multiplayer radio traffic
* FIXED: validate mission - player must be in mission sector
* FIXED: event IFF bugs
* FIXED: most fighters now have actual hardpoints (still need
      to do the Viper, Razor, and Cobra)

NEW CONTENT:
* Marakan Carrier (Dragon Class)
* Marakan Destroyer (Volnaris Class)
* Marakan Hvy Fighter (Raptor Class)
* Marakan Hvy Strike (Avenger Class)
* Alliance Interceptor (Falcon Class)
* New Starsystems (Jarnell, Silessia, Haiche, Borova, Athenar)

KNOWN ISSUES:
Campaign Three - Operation Shining Fortress is not finished
or balanced.  Don't bother reporting bugs that occur during
that campaign.

If you do finish Campaign Three, you will see Campaign Four
in the menu.  It doesn't exist, so don't try to play it. :-)




KNOWN ISSUES:


----------------------------------------------------------------

CONTACT INFORMATION

http://www.starshatter.com
milo@starshatter.com


The Starshatter Universe and all related indicia
Copyright � 1997-2003 John DiCamillo
All rights reserved.
