<?PHP
if ($ModType == "original")
			{
				echo "<td BGCOLOR=\"#E8E984\">Original</td>";
			}
		if ($ModType == "b5")
			{
				echo "<td BGCOLOR=\"#E8E984\">Babylon 5</td>";
			}
		if ($ModType == "saab")
			{
				echo "<td BGCOLOR=\"#E8E984\">Space: Above & ...</td>";
			}
		if ($ModType == "st")
			{
				echo "<td BGCOLOR=\"#E8E984\">Star Trek</td>";
			}
		if ($ModType == "sw")
			{
				echo "<td BGCOLOR=\"#E8E984\">Star Wars</td>";
			}
		if ($ModType == "bg")
			{
				echo "<td BGCOLOR=\"#E8E984\">Battlestar Galactica</td>";
			}
		if ($ModType == "fs")
			{
				echo "<td BGCOLOR=\"#E8E984\">Farscape</td>";
			}
		if ($ModType == "hw")
			{
				echo "<td BGCOLOR=\"#E8E984\">Homeworld</td>";
			}
		if ($ModType == "other")
			{
				echo "<td BGCOLOR=\"#E8E984\">Other</td>";
			}
		if ($ModType == "battletech")
			{
				echo "<td BGCOLOR=\"#E8E984\">Battletech</td>";
			}
		elseif($ModType == "")
			{
				echo"<td bgcolor=\"#E8E984\">---</td>";
			}
?>