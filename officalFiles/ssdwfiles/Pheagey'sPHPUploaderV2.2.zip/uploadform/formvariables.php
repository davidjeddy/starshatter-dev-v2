<?PHP
//$timedate1 = date("g:i a, F j, Y, ");
//$timedate2 = date("g:i a,");
//$timedate3 = date("F j, Y, ");
$the_path1="C:\apache\htdocs\ssdv2\userFiles\\";
$file_rename_path=$the_path1 . $object_type . "_" . $username . "_" . $mod_class . "_" . $object_name . "_";
$new_file_name=$mod_class . "_" .$object_type . "_" . $username . "_" . $object_name . "_" .  ".zip";
$the_img1_name=$mod_class . "_" .$object_type . "_" . $username . "_" . $object_name . "-1.jpg";
$the_img2_name=$mod_class . "_" .$object_type . "_" . $username . "_" . $object_name . "-2.jpg";
//$writephpfile=$mod_class . "_" .$object_type . "_" . $username . "_" . $object_name . ".php";
$errorchecker1=0;
$errorchecker2=1;
?>