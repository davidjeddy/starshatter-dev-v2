<?PHP
		$ob_nm_spaces = $object_name;
		$object_name = (str_replace(" ","",$ob_nm_spaces));
		$the_fl_nm_wspaces = $the_file_name;
		$the_file_name = (str_replace(" ","",$the_fl_nm_wspaces));	
		$the_writephpfile_wspaces = $writephpfile;
		$writephpfile = (str_replace(" ","",$the_writephpfile_wspaces));
?>