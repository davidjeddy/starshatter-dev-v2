<?PHP
echo "the_path1= ";echo $the_path1; echo "<BR>";
echo "file_rename_path= ";echo $file_rename_path; echo "<BR>";
echo "errorchecker1(over 0 is bad)= "; echo $errorchecker1; echo "<BR>";
echo "errorchecker2(should stay at 1)= "; echo $errorchecker2; echo "<BR><br>";
?>