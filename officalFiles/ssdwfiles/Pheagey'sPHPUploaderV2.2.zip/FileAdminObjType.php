<?PHP
		if ($FileObjType == "Drone")
			{
				echo "<td BGCOLOR=\"#E8E984\">Drone</td>";
			}
		if ($FileObjType == "Fighter")
			{
				echo "<td BGCOLOR=\"#E8E984\">Fighter</td>";
			}
		if ($FileObjType == "Attack")
			{
				echo "<td BGCOLOR=\"#E8E984\">Attack</td>";
			}
		if ($FileObjType == "LCA")
			{
				echo "<td BGCOLOR=\"#E8E984\">LCA</td>";
			}
		if ($FileObjType == "Tug")
			{
				echo "<td BGCOLOR=\"#E8E984\">Tug</td>";
			}
		if ($FileObjType == "Corvette")
			{
				echo "<td BGCOLOR=\"#E8E984\">Corvette</td>";
			}
		if ($FileObjType == "Frigate")
			{
				echo "<td BGCOLOR=\"#E8E984\">Frigate</td>";
			}
		if ($FileObjType == "Destroyer")
			{
				echo "<td BGCOLOR=\"#E8E984\">Destroyer</td>";
			}
		if ($FileObjType == "Cruiser")
			{
				echo "<td BGCOLOR=\"#E8E984\">Cruiser</td>";
			}
		if ($FileObjType == "Carrier")
			{
				echo "<td BGCOLOR=\"#E8E984\">Carrier</td>";
			}
		if ($FileObjType == "Drednaught")
			{
				echo "<td BGCOLOR=\"#E8E984\">Drednaught</td>";
			}
		if ($FileObjType == "Freighter")
			{
				echo "<td BGCOLOR=\"#E8E984\">Freighter</td>";
			}
		if ($FileObjType == "Station")
			{
				echo "<td BGCOLOR=\"#E8E984\">Station</td>";
			}
		if ($FileObjType == "Farcaster")
			{
				echo "<td BGCOLOR=\"#E8E984\">Farcaster</td>";
			}
		if ($FileObjType == "OtherStation")
			{
				echo "<td BGCOLOR=\"#E8E984\">Other Station</td>";
			}
		if ($FileObjType == "Corvette")
			{
				echo "<td BGCOLOR=\"#E8E984\">Corvette</td>";
			}
		if ($FileObjType == "Building")
			{
				echo "<td BGCOLOR=\"#E8E984\">Building</td>";
			}
		if ($FileObjType == "Factory")
			{
				echo "<td BGCOLOR=\"#E8E984\">Factory</td>";
			}
		if ($FileObjType == "SAM")
			{
				echo "<td BGCOLOR=\"#E8E984\">SAM</td>";
			}
		if ($FileObjType == "EWR")
			{
				echo "<td BGCOLOR=\"#E8E984\">EWR</td>";
			}
		if ($FileObjType == "C3I")
			{
				echo "<td BGCOLOR=\"#E8E984\">C3I</td>";
			}
		if ($FileObjType == "Starbase")
			{
				echo "<td BGCOLOR=\"#E8E984\">Starbase</td>";
			}
		if ($FileObjType == "Weapon")
			{
				echo "<td BGCOLOR=\"#E8E984\">Weapon</td>";
			}
		if ($FileObjType == "Mission")
			{
				echo "<td BGCOLOR=\"#E8E984\">Mission</td>";
			}
		if ($FileObjType == "Campaign")
			{
				echo "<td BGCOLOR=\"#E8E984\">Campaign</td>";
			}
		if ($FileObjType == "Universe")
			{
				echo "<td BGCOLOR=\"#E8E984\">Universe</td>";
			}
		if ($FileObjType == "OtherStuff")
			{
				echo "<td BGCOLOR=\"#E8E984\">Other</td>";
			}
		elseif($FileObjType == "")
			{
				echo "<td BGCOLOR=\"#E8E984\">---</td>";
			}
?>