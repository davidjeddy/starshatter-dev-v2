   /------------------------\
   |                        |
   |  SILVERCOUNTER README  |
   |                        |
   \------------------------/


REQUIREMENTS:
-------------

1. PHP webspace and a MySQL database



INSTALLATION:
-------------

1. Unzip "silvercounter_en.zip" with WinZip or something like that.
2. Open "counter.php" with a text editor and enter your correct MySQL login data.
3. Upload all unzipped files onto your webserver. Use ASCII mode for all files.
4. Open "install.php" with your browser and follow further instructions.
5. Delete "install.php" from your webserver after finishing the installation. (IMPORTANT!!)
6. Log in into your Admin Control Panel.
7. To include the counter into a website you only have to paste the PHP-code, which you can find in the Admin Control Panel, into a existing file. Please note that the files must have the ending *.php.



UPDATE (FROM 1.0 TO 1.0.1):
---------------------------

1. Overwrite the counter.php on the webserver with the new one from the archive.
2. Open counter.php with a text editor and enter your correct MySQL login data.


To login into your Admin Control Panel you have to open counter.php?action=login


If an error occurs or if you have any questions visit our support forums! (http://www.silver-scripts.de/board/index.php)!


Greets to everybody, who helped me! (Especially Tyrant) :-)