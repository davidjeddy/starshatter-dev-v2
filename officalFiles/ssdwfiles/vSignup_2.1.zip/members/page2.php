<?
/*
# File: page2.php
# Script Name: vAuthenticate 2.8
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vAuthenticate is a revolutionary authentication script which uses
# PHP and MySQL for lightning fast processing. vAuthenticate comes 
# with an admin interface where webmasters and administrators can
# create new user accounts, new user groups, activate/inactivate 
# groups or individual accounts, set user level, etc. This may be
# used to protect files for member-only areas. vAuthenticate 
# uses a custom class to handle the bulk of insertion, updates, and
# deletion of data. This class can also be used for other applications
# which needs user authentication.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006
*/
?>

<?
	if (!class_exists(auth))
	{
		include ("../auth.php");
	} 
		include ("../authconfig.php");
		include ("../check.php");	
?>
<head><title>Sample Page</title></head>
<body bgcolor="#FFFFFF">
<font color="#000066"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="3">If 
you can see this, you have logged in successfully a while ago and you're trying 
to access this page via direct method. You will continue to 
be able to directly access files until you close all browsers.</font></b></font>