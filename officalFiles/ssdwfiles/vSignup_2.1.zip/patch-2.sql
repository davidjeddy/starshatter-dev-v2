# File: patch-2.sql
# Script Name: vSignup 2.1
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vSignup is a member registration script which utilizes vAuthenticate
# for its security handling. This handy script features email verification,
# sending confirmation email message, restricting email domains that are 
# allowed for membership, and much more.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006

# Add 2 new columns in authuser table
ALTER TABLE authuser ADD lastlogin DATETIME, ADD logincount INT; 

# Update table values to make lastlogin and logincount not NULL
UPDATE authuser SET lastlogin = '', logincount = 0;

# BELOW ARE SQL SCRIPTS TO CREATE TABLES AND INITIAL 
# VALUES THAT WERE ADDED IN vSIGNUP 2.1

#
# Table structure for table `emailer`
#

CREATE TABLE emailer (
  id int(11) NOT NULL auto_increment,
  profile varchar(20) NOT NULL default '',
  email varchar(40) NOT NULL default '',
  name varchar(50) NOT NULL default '',
  subject varchar(100) NOT NULL default '',
  emailmessage text NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY id (id,profile),
  KEY profile (profile)
) TYPE=MyISAM;

#
# Dumping data for table `emailer`
#

INSERT INTO emailer VALUES (2, 'Default', 'membership@domain.com', 'Membership', 'Your Membership Confirmation', 'Hi!\r\n\r\nPlease click [[<-here->]] to confirm your membership. If your email client does not support HTML messages, open a new browser then copy this URL ([[--]]) and paste it in the location bar. \r\n\r\nRegards,\r\nMembership Department');
INSERT INTO emailer VALUES (5, 'Password Reminder', 'membership@domain.com', 'Membership', 'Your Password Reminder', 'Hello!\r\n\r\nYou have recently requested to have your password emailed to this address. \r\n\r\nYour password is: [[--]]\r\n\r\nIf you think that you did not request for this info, please disregard this message and accept our apologies for taking your time.\r\n\r\nThank you and good day!\r\n\r\nSincerely,\r\nMembership Department');
# --------------------------------------------------------

#
# Table structure for table `signupsetup`
#

CREATE TABLE signupsetup (
  id int(11) NOT NULL auto_increment,
  validemail text,
  profile varchar(20) NOT NULL default '',
  autoapprove tinyint(4) NOT NULL default '0',
  autosend tinyint(4) NOT NULL default '0',
  autosendadmin tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY id (id)
) TYPE=MyISAM;

#
# Dumping data for table `signupsetup`
#

INSERT INTO signupsetup VALUES (1, '', 'Default', 0, 1, 0);
