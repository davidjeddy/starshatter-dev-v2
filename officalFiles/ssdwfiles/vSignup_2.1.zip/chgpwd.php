<?
/*
# File: chgpwd.php
# Script Name: vSignup 2.1
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vSignup is a member registration script which utilizes vAuthenticate
# for its security handling. This handy script features email verification,
# sending confirmation email message, restricting email domains that are 
# allowed for membership, and much more.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006
*/
?>
<?
	if (!class_exists(auth))
	{
		include ("auth.php");
	} 
		include ("authconfig.php");
		include ("check.php");
?>

<head><title>Change Password</title></head>
<body bgcolor="#FFFFFF">

<p align="center"><b><font face="Arial">Change Password</font></b></p>
<div align="center">
  <center>
  <form method="POST" action="chgpwd.php">
  <table border="0" cellpadding="0" cellspacing="0" width="40%">
    <tr>
      <td width="100%" bgcolor="#C0C0C0" colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td width="34%" bgcolor="#C0C0C0"><b><font size="2" face="Arial">&nbsp; Old Password:</font></b></td>
      <td width="66%" bgcolor="#C0C0C0">
      <input type="password" name="oldpasswd" size="25"></td>
    </tr>
    <tr>
      <td width="34%" bgcolor="#C0C0C0"><b><font size="2" face="Arial">&nbsp; New Password:</font></b></td>
      <td width="66%" bgcolor="#C0C0C0">
      <input type="password" name="newpasswd" size="25"></td>
    </tr>
    <tr>
      <td width="34%" bgcolor="#C0C0C0"><b><font size="2" face="Arial">&nbsp; Confirm:</font></b></td>
      <td width="66%" bgcolor="#C0C0C0">
      <input type="password" name="confirmpasswd" size="25"></td>
    </tr>
    <tr>
      <td width="100%" colspan="2" bgcolor="#C0C0C0">&nbsp; </td>
    </tr>
    <tr>
      <td width="100%" colspan="2" bgcolor="#C0C0C0">
      <p align="center"><input type="submit" value="Save Changes" name="submit">
      <input type="reset" value="Reset Fields" name="reset"></td>
    </tr>
    <tr>
      <td width="100%" colspan="2" bgcolor="#C0C0C0">&nbsp;
       </td>
    </tr>
  </table>      
  </form>
  </center>
</div>

<? 
	$user = new auth();
	$connection = mysql_connect($dbhost, $dbusername, $dbpass);
	
	// REVISED CODE
	$SelectedDB = mysql_select_db($dbname);
	$userdata = mysql_query("SELECT * FROM authuserWHERE uname='$USERNAME' and passwd='$PASSWORD'");
	
	if ($submit)
	{
		// Check if Old password is the correct
		if ($oldpasswd != $PASSWORD)
		{
			print "<p align=\"center\">";
			print "	<font face=\"Arial\" color=\"#FF0000\">";
			print "		<b>Old password is wrong!</b>";
			print "	</font>";
			print "</p>";
			exit;
		}
		
		// Check if New password if blank
		if (trim($newpasswd) == "")
		{
			print "<p align=\"center\">";
			print "	<font face=\"Arial\" color=\"#FF0000\">";
			print "		<b>New password cannot be blank!</b>";
			print "	</font>";
			print "</p>";
			exit;
		}
				
		// Check if New password is confirmed
		if ($newpasswd != $confirmpasswd)
		{
			print "<p align=\"center\">";
			print "	<font face=\"Arial\" color=\"#FF0000\">";
			print "		<b>New password was not confirmed!</b>";
			print "	</font>";
			print "</p>";
			exit;
		}
		
		// If everything is ok, use auth class to modify the record
		$update = $user->modify_user($USERNAME, $newpasswd, $check["team"], $check["level"], $check["status"]);
		if ($update) {
			print "<p align=\"center\">";
			print "	<font face=\"Arial\" color=\"#FF0000\">";
			print "		<b>Password Changed!</b><br>";
			print "		You will be required to re-login so that your session will recognize the new password. <BR>";
			print "		Click <a href=\"$login\">here</a> to login again.";
			print "	</font>";
			print "</p>";
		}
		
	}	// end - new password field is not empty
?>

</body>