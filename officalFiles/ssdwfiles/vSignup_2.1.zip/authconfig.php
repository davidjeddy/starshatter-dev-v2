<?
/*
# File: authconfig.php
# Script Name: vSignup 2.1
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vSignup is a member registration script which utilizes vAuthenticate
# for its security handling. This handy script features email verification,
# sending confirmation email message, restricting email domains that are 
# allowed for membership, and much more.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006
*/
?>
<?
// ALL PATHS BELOW ARE RELATIVE TO THE DIRECTORY WHERE YOU HAVE INSTALLED vAuthenticate
$resultpage = "vAuthenticate.php";	// THIS IS THE PAGE THAT WOULD CHECK FOR AUTHENTICITY
$admin = "admin/index.php";	// THIS IS THE PATH TO THE ADMIN INTERFACE
$success = "members/index.php";	// THIS IS THE PAGE TO BE SHOWN IF USER IS AUTHENTICATED
$failure = "failed.php";	// THIS IS THE PAGE TO BE SHOWN IF USERNAME-PASSWORD COMBINATION DOES NOT MATCH
	
// ALL VARIABLES BELOW SHOULD HAVE THE FULL URL ASSIGNED TO THEM
$changepassword = "http://localhost/Scripts/vSignup/chgpwd.php"; // FULL URL TO THE CHANGE PASSWORD FILE
$login = "http://localhost/Scripts/vSignup/login.php"; // FULL URL TO THE LOGIN PAGE
$logout = "http://localhost/Scripts/vSignup/logout.php"; // FULL URL TO THE LOGOUT FILE
			
// DB SETTINGS
$dbhost = "localhost";	// DB Host name
$dbusername = "root"; 	// DB User
$dbpass = "";	// DB User password
$dbname	= "test-signup"; 	// DB Name

?>