<?
/*
# File: pwdremind.php
# Script Name: vSignup 2.1
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vSignup is a member registration script which utilizes vAuthenticate
# for its security handling. This handy script features email verification,
# sending confirmation email message, restricting email domains that are 
# allowed for membership, and much more.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006
*/
?>
<html>
<head>
<title>vSignup Password Reminder</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<p><font face="Arial, Helvetica, sans-serif" size="4"><b>PASSWORD REMINDER</b></font></p>
<table width="60%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><font face="Arial, Helvetica, sans-serif" size="2">Please 
      enter your username below and click &quot;Send&quot; to receive your password 
      again via email. The message will be sent to the email address you've specified 
      during the signup process. </font></td>
  </tr>
</table>
<form name="Sample" method="post" action="process.php">
	<font face="Arial, Helvetica, sans-serif" size="2">
		<b>Username: </b>
		<input type="text" name="username" size="15" maxlength="15">
		<input type="submit" name="remind" value="Send">
	</font>
</form>
<br>
</body>
</html>
