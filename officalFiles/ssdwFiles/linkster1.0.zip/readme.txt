#
# readme.txt
#
# *******************************************************
# *                                                     *
# *   Linkster 1.0 - a PHP/MySQL link indexing script   *
# *                                                     *
# *                 [ March 21, 2001 ]                  *
# *                                                     *
# *******************************************************
#
# Copyright 2001 Steve Gliebe. All rights reserved.
#
# Linkster 1.0 is distributed by Dream Dolphin Studio (http://dreamdolphin.com) as freeware.
# It may be used and modified for your own use as long as this copyright/usage note remains
# intact and unchanged in each place it appears. You may not sell or distribute the code of
# Linkster 1.0, in whole or part, without the expressed written consent of Steve Gliebe and
# Dream Dolphin Studio.
#
# By using Linkster 1.0 you agree to indemnify Steve Gliebe and Dream Dolphin Studio from
# any liability.
#
# Being freeware, support for this script is not offered by Steve Gliebe or Dream Dolphin
# Studio. Installation is offered for a small fee by Dream Dolphin Studio as well as custom
# programming, web design, and graphic design services. Visit http://dreamdolphin.com for
# more information.
#


-----------------------
 OVERVIEW
-----------------------

Linkster is a MySQL database driven link indexing script written in PHP 3. It has two
modes of display. Flat mode displays all categories and links on one page while leveled
mode gives each category its own page. Linkster keeps a click count for each link but it
is up to you whether or not you want to display it. There are three sorting options for
links and categories: alphabetical, newest to oldest, and oldest to newest. If you want
visitors to your website to be able to add links, you may enable 'public_add'. If you
choose not to, then links will have to be added with Linkster's admin script. Using
the admin script, you may add/modify/remove any links or categories. Because of table
and color varibles in common.php and the use of header/footer templates, customizing the
appearance of Linkster is easy.


------------------------
 REQUIREMENTS
------------------------

- PHP 3 or higher
- MySQL database


------------------------
 FILES
------------------------

common.php         - PHP code shared by linkster.php and admin.php
create_tables.php  - script used to create Linkster's tables in your database
admin.php    	   - script used for adding/modifying/removing categories/links
linkster.php 	   - script that displays categories and links
header.inc    	   - HTML code used on the top of all pages
footer.inc    	   - HTML code used on the bottom of all pages


------------------------
 INSTALLATION
------------------------

Step 1:
 Create a new MySQL database (or choose an existing one). Create a new user (or use an
 existing user) with access to that database with (at minimum) the following privileges:
 SELECT, INSERT, UPDATE, DELETE, and CREATE.

Step 1:
 Edit all "CONFIGURATION" variables in common.php.

Step 2:
 Create a directory on your server and transfer the following files into it: linkster.php,
 admin.php, common.php, create_tables.php, header.inc, and footer.inc.

Step 3:
 Load create_tables.php in your web browser then remove it from your server. If you get a
 MySQL error, make sure your database/user is setup correctly and the database variables in
 common.php are valid.

Step 4:
 Go to admin.php, enter your password, then add a new category. It will not show up on
 linkster.php until you add a link to it. After you add a link, Linkster should be running
 fine.

Read the section below for visual customization information.


------------------------
 VISUAL CUSTOMIZATION
------------------------

Using the 'table settings' in common.php, you can control the color and size, among other
things, of the link/category tables in Linkster.

You can edit header.inc and footer.inc to match your site. If you wish to use your
own template files and they are in a different directory on your server, use the
absolute path in common.php (i.e. /home/bob/public_html/header.inc)' instead of the
relative path (i.e. header.inc).

Linkster uses CSS to control text styles. Take a peek at the stylesheet in header.inc. The
following ID's control how text appears. Feel free to edit them.

 #linkster-title-large:  category titles, titles in admin
 #linkster-title-small:  small titles (i.e. "Link/Description" and "Clicks" in row 2)
 #linkster-cat-desc:     category descriptions in flat mode
 #linkster-list:         rows containing links/descriptions/clicks in flat mode plus
                         categories/link counts in leveled mode
 #linkster-count:        click counts in flat plus link count in leveled mode

If you are using template files elsewhere on your server, be sure to
include these style ID's in a stylesheet or parts of Linkster will appear as regular text.
If you need some help with CSS, check out Mulder's Stylesheets Tutorial at Webmonkey:
http://hotwired.lycos.com/webmonkey/98/15/index0a.html.


------------------------
 MISC. NOTES
------------------------

- Empty categories are not displayed in flat mode. They are displayed in leveled mode's
  category list but not linked to a page of links since there are none.
- When you log in to admin.php, a cookie is set with an expiration time of 30 minutes.
  If you are still in the admin script after 30 minutes, you will need to log in again.
- If you get a MySQL error message, you most likely misconfigured $mysql_server, $database,
  $user, and/or $password in common.php.
- You can rename linkster.php and admin.php but they must remain in the same directory as
  common.php. 


#####################################################

Enjoy Linkster!
