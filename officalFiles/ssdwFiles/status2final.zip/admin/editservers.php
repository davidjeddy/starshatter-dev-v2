<?
//---------------------------------------------------------------------------//
// Author:	Marc Hanlon <marc@rushland.net> 
// Date:	19-Oct-02
// Web:		http://www.rushland.net
// Info:	Server Status
// Version:	2.0b2
// Copyright (c) 2002. Marc Hanlon.
//---------------------------------------------------------------------------//
// License
//---------------------------------------------------------------------------//
// This file is part of Server Status.
//
// Server Status is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Server Status is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Server Status; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//---------------------------------------------------------------------------//
	require("../config.php");
	require("../phemplate.class.php");
	require("../globals.php");
	ob_start("admin_output");
	$dbconn = mysql_pconnect($config["dbserver"],$config["dbuser"],$config["dbpass"]) or die ("Could not connect to mySQL server");
	if (!mysql_select_db($config["dbname"])) {
		die("Could not select database (" . $config["dbname"] . ")!");
	}
	if (strtolower($_POST["action"]) == "save") {
		$nameSQL = addslashes($_POST["servername"]);
		if ($_POST["serverip"] == "") {
			$ipSQL = 0;
		} else {
			$ipSQL = addslashes($_POST["serverip"]);
		}
		if ($_POST["serverhost"] == "") {
			$hostSQL = 0;
		} else {
			$hostSQL = addslashes($_POST["serverhost"]);
		}
		$groupSQL = (int) $_POST["servergroup"];
		$query = mysql_query("INSERT into servers (`friendlyname`,`ip`,`hostname`,`groupid`) values ('$nameSQL','$ipSQL','$hostSQL','$groupSQL')");
	}
	if (strtolower($_POST["action"]) == "delete") {
		$deleteSQL = join(",",$_POST["deletethese"]);
		$query = mysql_query("DELETE from servers where id in ($deleteSQL)");
	}
?>
<DIV class=box><form method="post" name="deleteform" action="editservers.php" onsubmit="return confirm('Are you sure you wish to delete thse entries?');">
      <H3 class=boxheader>Current Servers</H3>
      <div class="spacer">
	    <table width="100%" border="0" cellspacing="0" cellpadding="2" align="center">
	<tr>
		<th>Name:</th>
		<th>IP:</th>
		<th>Host:</th>
		<th>Group:</th>
	</tr>
<?
	$getservers = mysql_query("SELECT `id`,`friendlyname`,`ip`,`hostname`,`groupname` from servers left join groups using (groupid)");
	while ($row=mysql_fetch_array($getservers)) {
		if ($row[2] == "0") { $row[2] = "-"; }
		if ($row[3] == "0") { $row[3] = "-"; }
print <<<HTML
	<tr bgcolor="#006531">
          <td><INPUT TYPE="checkbox" NAME="deletethese[]" value="$row[0]">$row[1]</td>
	      <td>$row[2]</td>
		  <td>$row[3]</td>
		  <td>$row[4]</td>
    </tr>
HTML;
	}
	$getgroups = mysql_query("SELECT `groupid`,`groupname` from groups");
	while ($row = mysql_fetch_row($getgroups)) {
		$servergroups[$row[0]] = $row[1];
	}
	$serveroptions = genOptions($servergroups);
?>
<tr>
	<th align="right" colspan="4">Delete selected: <INPUT TYPE="submit" name="action" value="Delete"></th>
</tr>
</table>
</div>
</div>
</form>
<form method="post" name="addform" action="editservers.php">
<DIV class=box>
      <H3 class=boxheader>New Server</H3>
      <div class="leftspacer">
			<div>Name: <INPUT TYPE="text" NAME="servername" maxlength="50"></div>
			<div>IP: <INPUT TYPE="text" NAME="serverip" maxlength="16"> or host: <INPUT TYPE="text" NAME="serverhost" maxlength="100"></div>
			<div>In: <SELECT name="servergroup"><?=$serveroptions?></SELECT></div>
			<div><INPUT TYPE="submit" name="action" value="Save"></div>
	  </div>
</DIV>
</form>
<?
	ob_end_flush();
?>