<?
	require("../config.php");
	require("../phemplate.class.php");
	require("../globals.php");
	ob_start("admin_output");
	$dbconn = mysql_pconnect($config["dbserver"],$config["dbuser"],$config["dbpass"]) or die ("Could not connect to mySQL server");
	if (!mysql_select_db($config["dbname"])) {
		die("Could not select database (" . $config["dbname"] . ")!");
	}
	if (strtolower($_POST["action"]) == "save") {
		$portSQL = addslashes($_POST["portid"]);
		$portnameSQL = addslashes($_POST["portname"]);
		$query = mysql_query("INSERT into ports (`portid`,`portname`) values ('$portSQL','$portnameSQL')");
	}
	if (strtolower($_POST["action"]) == "delete") {
		$deleteSQL = join(",",$_POST["deletethese"]);
		$query = mysql_query("DELETE from ports where portid in ($deleteSQL)");
	}
?>
<DIV class=box>
<form method="post" name="deleteform" action="editservices.php" onsubmit="return confirm('Are you sure you wish to delete thse entries?');">
      <H3 class=boxheader>Current Services</H3>
      <div class="spacer">
	    <table width="100%" border="0" cellspacing="0" cellpadding="2" align="center">
		<tr>
			<th>Port:</th>
			<th>Service:</th>
		</tr>
<?
	$getservices = mysql_query("SELECT `portid`,`portname` from ports order by portid");
	while ($row=mysql_fetch_array($getservices)) {
print <<<HTML
	<tr bgcolor="#006531">
          <td><INPUT TYPE="checkbox" NAME="deletethese[]" value="$row[0]">Port $row[0]</td>
	      <td>$row[1]</td>
    </tr>
HTML;
	}
?>
<tr>
	<th align="right" colspan="2">Delete selected: <INPUT TYPE="submit" name="action" value="Delete"></th>
</tr>
</table>
</div>
</div>
</form>
<form method="post" name="addform" action="editservices.php">
<DIV class=box>
      <H3 class=boxheader>New Service</H3>
      <div class="spacer">
			Port No: <INPUT TYPE="text" NAME="portid" size="5"> Name: <INPUT TYPE="text" NAME="portname" maxlength="10"> <INPUT TYPE="submit" name="action" value="Save">
	  </div>
</DIV>
</form>
<?
	ob_end_flush();
?>