<?
//---------------------------------------------------------------------------//
// Author:	Marc Hanlon <marc@rushland.net> 
// Date:	19-Oct-02
// Web:		http://www.rushland.net
// Info:	Server Status
// Version:	2.0b2
// Copyright (c) 2002. Marc Hanlon.
//---------------------------------------------------------------------------//
// License
//---------------------------------------------------------------------------//
// This file is part of Server Status.
//
// Server Status is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Server Status is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Server Status; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//---------------------------------------------------------------------------//
	require("../phemplate.class.php");
	require("../globals.php");
	ob_start("admin_output");
?>
	<DIV class="box">
      <H3 class=boxheader>Administration</H3>
      <div class="spacer" style="padding: 10px;text-align: left">
			<p><a href="editannouncements.php"><IMG SRC="../images/announce.gif" WIDTH="32" HEIGHT="32" BORDER=0 ALT="Edit announcements" align="absmiddle"> Edit Announcements</a></p>
			<p><a href="editservices.php"><IMG SRC="../images/services.gif" WIDTH="32" HEIGHT="32" BORDER=0 ALT="Edit services" align="absmiddle"> Edit Services</a></p>
			<p><a href="editgroups.php"><IMG SRC="../images/groups.gif" WIDTH="32" HEIGHT="32" BORDER=0 ALT="Edit groups" align="absmiddle"> Edit Groups</a></p>
			<p><a href="editservers.php"><IMG SRC="../images/servers.gif" WIDTH="32" HEIGHT="32" BORDER=0 ALT="Edit servers" align="absmiddle"> Edit Servers</a></p>
	  </div>
  </DIV>
<?
	ob_end_flush();
?>