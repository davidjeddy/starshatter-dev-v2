<?
//---------------------------------------------------------------------------//
// Author:	Marc Hanlon <marc@rushland.net> 
// Date:	19-Oct-02
// Web:		http://www.rushland.net
// Info:	Server Status
// Version:	2.0b2
// Copyright (c) 2002. Marc Hanlon.
//---------------------------------------------------------------------------//
// License
//---------------------------------------------------------------------------//
// This file is part of Server Status.
//
// Server Status is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Server Status is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Server Status; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//---------------------------------------------------------------------------//
	require("../config.php");
	require("../phemplate.class.php");
	require("../globals.php");
	ob_start("admin_output");
	$dbconn = mysql_pconnect($config["dbserver"],$config["dbuser"],$config["dbpass"]) or die ("Could not connect to mySQL server");
	if (!mysql_select_db($config["dbname"])) {
		die("Could not select database (" . $config["dbname"] . ")!");
	}
	if (strtolower($_POST["action"]) == "save" && $_POST["announcement"] != "") {
		$announceSQL = addslashes($_POST["announcement"]);
		$query = mysql_query("INSERT into announcements (`announcement`,`atime`) values ('$announceSQL',NOW())");
	}
	if (strtolower($_POST["action"]) == "delete") {
		$deleteSQL = join(",",$_POST["deletethese"]);
		$query = mysql_query("DELETE from announcements where id in ($deleteSQL)");
	}
?>
<DIV class=box><form method="post" name="deleteform" action="editannouncements.php" onsubmit="return confirm('Are you sure you wish to delete thse entries?');">
      <H3 class=boxheader>Current Announcements</H3>
      <div class="spacer">
	    <table width="100%" border="0" cellspacing="0" cellpadding="2" align="center">
<?
	$getannouncements = mysql_query("SELECT `id`,`announcement`,UNIX_TIMESTAMP(`atime`) as atime from announcements order by atime desc");
	while ($row=mysql_fetch_array($getannouncements)) {
		$row[2] = date($config["dateformat"],$row[2]);
print <<<HTML
	<tr bgcolor="#006531"> 
          <th align="left"><INPUT TYPE="checkbox" NAME="deletethese[]" value="$row[0]">$row[2]</th>
        </tr>
        <tr> 
          <td>$row[1]</td>
        </tr>
HTML;
	}
?>
<tr>
	<th align="right">Delete selected: <INPUT TYPE="submit" name="action" value="Delete"></th>
</tr>
</table>
</div>
</div>
</form>
<form method="post" name="addform" action="editannouncements.php">
<DIV class=box>
      <H3 class=boxheader>New Announcement</H3>
      <div class="leftspacer">
			<TEXTAREA NAME="announcement" ROWS="5" COLS="40"></TEXTAREA><br>
			<INPUT TYPE="submit" name="action" value="Save">
	  </div>
</DIV>
</form>
<?
	ob_end_flush();
?>