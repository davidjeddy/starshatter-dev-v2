<?
//---------------------------------------------------------------------------//
// Author:	Marc Hanlon <marc@rushland.net> 
// Date:	19-Oct-02
// Web:		http://www.rushland.net
// Info:	Server Status
// Version:	2.0b2
// Copyright (c) 2002. Marc Hanlon.
//---------------------------------------------------------------------------//
// License
//---------------------------------------------------------------------------//
// This file is part of Server Status.
//
// Server Status is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Server Status is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Server Status; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//---------------------------------------------------------------------------//
	require("../config.php");
	error_reporting(0);
	if (!mysql_pconnect($config["dbserver"],$config["dbuser"],$config["dbpass"])) {
		die("Could not connect to database server using login information provided. Please check config.php");
	}
	if (!mysql_select_db($config["dbname"])) {
		if (!mysql_create_db($config["dbname"])) {
			die("Could not create database " . $config["dbname"]);
		} else {
			mysql_select_db($config["dbname"]);
			print "Created database " . $config["dbname"] . "<br>";
		}
	}
	if (!mysql_query("SELECT * from announcements")) {
		mysql_query("CREATE TABLE `announcements` (`id` smallint(5) unsigned NOT NULL auto_increment,`announcement` tinytext NOT NULL,`atime` datetime NOT NULL default '2002-08-08 01:00:00',PRIMARY KEY  (`id`),UNIQUE KEY `id` (`id`),KEY `id_2` (`id`)) TYPE=MyISAM COMMENT='Service Announcements'");
		mysql_query("INSERT INTO announcements (announcement, atime) VALUES('Server Status 2 has been installed', NOW())");
		print "Created annoucements table<br>";
	}
	if (!mysql_query("SELECT * from groups")) {
		mysql_query("CREATE TABLE `groups` (`groupid` tinyint(3) unsigned NOT NULL auto_increment,`groupname` varchar(50) NOT NULL default '0',`ports` varchar(50) NOT NULL default '0',PRIMARY KEY (`groupid`),UNIQUE KEY `groupid` (`groupid`),KEY `groupid_2` (`groupid`)
) TYPE=MyISAM COMMENT='Server groups'");
		mysql_query("INSERT INTO groups (groupname, ports) VALUES('Web Servers','80,443')");
		print "Created groups table<br>";
	}
	if (!mysql_query("SELECT * from ports")) {
		mysql_query("CREATE TABLE `ports` (`portid` smallint(3) unsigned NOT NULL default '0',`portname` varchar(10) NOT NULL default '0',PRIMARY KEY  (`portid`),UNIQUE KEY `portid` (`portid`),KEY `portid_2` (`portid`)) TYPE=MyISAM COMMENT='Port numbers'");
		mysql_query("INSERT INTO ports (portid, portname) VALUES('80', 'HTTP')");
		mysql_query("INSERT INTO ports (portid, portname) VALUES('443', 'HTTPS')");
		print "Created ports table<br>";
	}
	if (!mysql_query("SELECT * from servers")) {
		mysql_query("CREATE TABLE `servers` (`id` tinyint(3) unsigned NOT NULL auto_increment,`friendlyname` varchar(50) NOT NULL default '0',`ip` varchar(16) NOT NULL default '0',`hostname` varchar(100) NOT NULL default '0',`groupid` tinyint(3) unsigned NOT NULL default '0',PRIMARY KEY  (`id`),UNIQUE KEY `id` (`id`),KEY `id_2` (`id`)) TYPE=MyISAM COMMENT='Servers to be monitored'");
		mysql_query("INSERT INTO servers (friendlyname, ip, hostname, groupid) VALUES('Local Server','127.0.0.1','0','1')");
		print "Created servers table<br>";
	}
	print "Successfully installed Server Status 2";
?>