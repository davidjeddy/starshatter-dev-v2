<?
//---------------------------------------------------------------------------//
// Author:	Marc Hanlon <marc@rushland.net> 
// Date:	19-Oct-02
// Web:		http://www.rushland.net
// Info:	Server Status
// Version:	2.0b2
// Copyright (c) 2002. Marc Hanlon.
//---------------------------------------------------------------------------//
// License
//---------------------------------------------------------------------------//
// This file is part of Server Status.
//
// Server Status is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Server Status is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Server Status; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//---------------------------------------------------------------------------//
	require("../config.php");
	require("../phemplate.class.php");
	require("../globals.php");
	ob_start("admin_output");
	$dbconn = mysql_pconnect($config["dbserver"],$config["dbuser"],$config["dbpass"]) or die ("Could not connect to mySQL server");
	if (!mysql_select_db($config["dbname"])) {
		die("Could not select database (" . $config["dbname"] . ")!");
	}
	if (strtolower($_POST["action"]) == "save") {
		$nameSQL = addslashes($_POST["servername"]);
		$portsSQL = addslashes(join(",",$_POST["ports"]));
		$query = mysql_query("INSERT into groups (`groupname`,`ports`) values ('$nameSQL','$portsSQL')");
	}
	if (strtolower($_POST["action"]) == "delete") {
		$deleteSQL = join(",",$_POST["deletethese"]);
		$query = mysql_query("DELETE from groups where groupid in ($deleteSQL)");
		$query = mysql_query("DELETE from servers where groupid in ($deleteSQL)");
	}
	$getservices = mysql_query("SELECT `portid`,`portname` from ports");
	while ($row = mysql_fetch_row($getservices)) {
		$services[$row[0]] = $row[1];
	}
?>
<DIV class=box><form method="post" name="deleteform" action="editgroups.php" onsubmit="return confirm('Are you sure you wish to delete thse entries? Servers in these groups will also be deleted!');">
      <H3 class=boxheader>Current Groups</H3>
      <div class="spacer">
	    <table width="100%" border="0" cellspacing="0" cellpadding="2" align="center">
		<tr>
			<th>Name:</th>
			<th>Ports:</th>
	</tr>
<?
	$getgroups = mysql_query("SELECT `groupid`,`groupname`,`ports` from groups");
	while ($row=mysql_fetch_array($getgroups)) {
		$row[2] = split(",",$row[2]);
		for ($i=0;$i<count($row[2]);$i++) {
			$row[2][$i] = $services[$row[2][$i]];
		}
		$row[2] = join(", ",$row[2]);
print <<<HTML
	<tr bgcolor="#006531">
          <td><INPUT TYPE="checkbox" NAME="deletethese[]" value="$row[0]">$row[1]</td>
		  <td>$row[2]</td>
    </tr>
HTML;
	}
	while ($port = each($services)) {
		$portchoices .= '<INPUT TYPE="checkbox" NAME="ports[]" value="' . $port["key"] . '"> ' . $port["value"];
	}
?>
<tr>
	<th align="right" colspan="2">Delete selected: <INPUT TYPE="submit" name="action" value="Delete"></th>
</tr>
</table>
</div>
</div>
</form>
<form method="post" name="addform" action="editgroups.php">
<DIV class=box>
      <H3 class=boxheader>New Group</H3>
      <div class="leftspacer">
			<div>Name: <INPUT TYPE="text" NAME="servername" maxlength="50"></div>
			<div>Ports: <?=$portchoices?></div>
			<div><INPUT TYPE="submit" name="action" value="Save"></div>
	  </div>
</DIV>
</form>
<?
	ob_end_flush();
?>