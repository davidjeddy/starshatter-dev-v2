<?
	$config = array();
	// IP or hostname of your database server
	$config["dbserver"] = "localhost";
	// The username to connect as
	$config["dbuser"] = "username";
	// Password to use
	$config["dbpass"] = "password";
	// DB to use (if it doesn't exist, the software will create it)
	$config["dbname"] = "status";
	// HTML code to display if a service is up
	$config["serviceup"] = '<img src="images/up.gif" alt="Service is up">';
	// HTML code to display if a service is down
	$config["servicedown"] = '<img src="images/down.gif" alt="Service is up">';
	// Time (in seconds) to wait before a service times out, you want this as low as possible but
	// setting it too low will cause false reports of downtime
	$config["timeout"] = '2';
	// Enable the announcement feature (0 to disable)
	$config["announce"] = 1;
	// Format to display date in (see http://www.php.net/manual/function.date.php3 to understand this)
	// Examples:
	// US (04-25-98) : 'm-d-y'
	// Expanded US (April 25th, 1998) : 'F jS, Y'
	// European (25-04-98) : 'd-m-Y'
	// Expanded European (25th April 1998) : 'jS F Y'
	// Time:
	// 'H:i' - 24 hour format (22:00)
	// 'h:i a' - 12 hours format (10:00 pm)
	$config["dateformat"] = 'jS F Y H:i';

	// Duration to cache results for (in minutes) (0 mins = no caching)
	$config["cache"] = 1;

	// File to cache results in, create it and make sure the web user can read & write to it (typically CHMOD 0666)
	$config["cachefile"] = "cache.htm";
?>