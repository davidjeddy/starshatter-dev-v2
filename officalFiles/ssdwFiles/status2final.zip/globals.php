<?
//---------------------------------------------------------------------------//
// Author:	Marc Hanlon <marc@rushland.net> 
// Date:	19-Oct-02
// Web:		http://www.rushland.net
// Info:	Server Status
// Version:	2.0b2
// Copyright (c) 2002. Marc Hanlon.
//---------------------------------------------------------------------------//
// License
//---------------------------------------------------------------------------//
// This file is part of Server Status.
//
// Server Status is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Server Status is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Server Status; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//---------------------------------------------------------------------------//
	function do_group($servers,$ports) {
		global $config,$phemplate,$portnames;
		$ports = preg_split("/[,]/",$ports);
		sort($ports);
		for ($i=0;$i<count($servers);$i++) {
			if ($servers[$i]["ip"] == "0") {
				$servers[$i]["ip"] = gethostbyname($servers[$i]["hostname"]);
			}
			if ($servers[$i]["hostname"] == "0") {
				$servers[$i]["hostname"] = gethostbyaddr($servers[$i]["ip"]);
			}
			foreach($ports as $thisport) {
				if (isset($portnames[$thisport]["name"])) {
					$theseports[$thisport]["name"] = $portnames[$thisport]["name"];
				} else {
					$theseports[$thisport]["name"] = "Port " . $thisport;
				}
				$tcpconn = fsockopen($servers[$i]["ip"],$thisport,$errno,$errstr,$config["timeout"]);
				if ($tcpconn) {
					$servers[$i]["stats"] .= '<td class="serviceup" align="center">' . $config["serviceup"] . '</td>';
					fclose($tcpconn);
				} else {
					$servers[$i]["stats"] .= '<td class="servicedown" align="center">' . $config["servicedown"] . '</td>';
				}
			}
		}
		$phemplate->set_file('groups','templates/groups.htm');
		$phemplate->set_loop('heads',$theseports);
		$phemplate->set_loop('servers',$servers);
		return $phemplate->process('proc_groups','groups',2);
	}

	function admin_output($buffer) {
		global $adminmsgs;
		$phemplate = new phemplate();
		$phemplate->set_file("admin","../templates/admin.htm",1);
		$phemplate->set_var('content',$buffer);
		if (count($adminmsgs) < 1) {
			$phemplate->set_var('messages','');
		} else {
			$phemplate->set_var('messages',join("<br />",$adminmsgs));
		}
		return $phemplate->process("adminout","admin");
	}

	function genOptions($passedarray,$default="") {
		while ($thiskey = key($passedarray)) {
			$returnval .= "<option value=\"$thiskey\"";
			if ($thiskey == $default) { $returnval .= " selected"; }
			$returnval .= ">" . $passedarray[$thiskey] . "</option>";
			next($passedarray);
		}
		return $returnval;
	}

	function cachepage($buffer) {
		global $config;
		if ($config["cache"] > 0) {
			$cacheto = fopen($config["cachefile"],"w");
			fwrite($cacheto,$buffer);
			fclose($cacheto);
		}
		return $buffer;
	}
?>