<?
//---------------------------------------------------------------------------//
// Author:	Marc Hanlon <marc@rushland.net> 
// Date:	19-Oct-02
// Web:		http://www.rushland.net
// Info:	Server Status
// Version:	2.0b2
// Copyright (c) 2002. Marc Hanlon.
//---------------------------------------------------------------------------//
// License
//---------------------------------------------------------------------------//
// This file is part of Server Status.
//
// Server Status is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Server Status is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Server Status; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//---------------------------------------------------------------------------//

	require("config.php");
	require("phemplate.class.php");
	require("globals.php");

	error_reporting(7);

	$dbconn = mysql_pconnect($config["dbserver"],$config["dbuser"],$config["dbpass"]) or die ("Could not connect to mySQL server");
	if (!mysql_select_db($config["dbname"])) {
		die("Could not select database (" . $config["dbname"] . ")!");
	}

	$getgroups = mysql_query("SELECT `groupid`,`groupname`,`ports` from groups");
	if (mysql_num_rows($getgroups) < 1) {
		die("No server groups in database");
	}

	$getports = mysql_query("SELECT `portid`,`portname` from ports");
	if (mysql_num_rows($getports) < 1) {
		die ("No services available to check");
	}
	while ($row = mysql_fetch_row($getports)) {
		$portnames[$row[0]]["name"] = $row[1];
	}

	$phemplate = new phemplate();

	if ($config["cache"] > 0 && (time()-@filemtime($config["cachefile"]) < $config["cache"]*60)) {
		$cachedpage=fopen($config["cachefile"],"r");
		fpassthru($cachedpage);
		exit;
	}

	while ($row = mysql_fetch_array($getgroups)) {
		$i=0;
		$servers=array();
		$id=$row["groupid"];
		$groups[$id]["name"] = $row["groupname"];
		$getservers = mysql_query("SELECT `friendlyname`,`ip`,`hostname` from servers where groupid='$id' order by `friendlyname`");
		while ($server = mysql_fetch_array($getservers)) {
			$servers[$i]["friendly"] = $server["friendlyname"];
			$servers[$i]["ip"] = $server["ip"];
			$servers[$i]["hostname"] = $server["hostname"];
			$i++;
		}
		$groups[$id]["output"] = do_group($servers,$row["ports"]);
	}

	if ($config["announce"]) {
		$getannouncements = mysql_query("SELECT `announcement`,UNIX_TIMESTAMP(`atime`) as atime from announcements order by atime desc LIMIT 0,5");
		while ($row=mysql_fetch_array($getannouncements)) {
			$announces[$aindex]["announcement"] = $row["announcement"];
			$announces[$aindex++]["atime"] = date($config["dateformat"],$row["atime"]);
		}
		$phemplate->set_file('announce','templates/announcements.htm');
		$phemplate->set_loop('announcements',$announces);
		$announcements = $phemplate->process('proc_announce','announce',2);
	} else {
		$announcements = "";
	}
	
	ob_start("cachepage");
	$phemplate->set_file('main','templates/main.htm');
	$phemplate->set_var('announcements',$announcements);
	if ($config["cache"]) {
		$phemplate->set_var('cacheinfo','<p class="main">Page is generated every '.$config["cache"].' minute(s). Page last generated: '.date($config["dateformat"]).'.</p>');
	} else {
		$phemplate->set_var('cacheinfo','');
	}
	$phemplate->set_var('timezone',date("T") . " (GMT " . preg_replace("/([+-])([\d]{2})([\d]{2})/","\\1\\2:\\3",date("O")) . ")");
	$phemplate->set_loop('groups',$groups);
	echo $phemplate->process('proc_main','main',1);
	ob_end_flush();
?>